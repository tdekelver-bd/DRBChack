#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(elia)
library(shinydashboard)
library(shinydashboardPlus)
library(ggplot2)
library(dygraphs)


sidebar <- dashboardSidebar(width = 300,
  sidebarMenu(
    menuItem(span("Top Issues",style="font-size:18px;"), tabName = "topissue", icon = icon("exclamation-triangle")),
    menuItem(span("Explore Contingencies",style="font-size:18px;"), icon = icon("ban"), tabName = "explorecontingencies")
  )
)

body <- dashboardBody(
  # tags$head(tags$style(HTML(' .main-sidebar{ width: 350px; } .main-header > .navbar { margin-left: 350px; } .main-header .logo { width: 350px; } .content-wrapper, .main-footer, .right-side { margin-left: 350px; } '))),
  tabItems(
    tabItem(tabName = "topissue",
            h2("Top Issues")
            ,hr()
            ,selectInput("topissue_var", "Prioritisation",c("max_loading_perc","loading_perc"))
            ,DT::dataTableOutput("topissue_dt_elements")
            ,hr()
            ,fluidRow(tabBox(
              title = tagList(shiny::icon("alert"), "Contingency Issues"), width = 12,
              tabPanel("Issue time-series",value="topissue_element_timeserie", dygraphs::dygraphOutput("topissue_timeseries_graph")),
              tabPanel("Elements correlated with issue",value="topissue_element_correlation",
                       fluidRow(dygraphs::dygraphOutput("topissue_correlations_graph"),
                       br(),
                       fluidRow(DT::dataTableOutput("topissue_correlations_dt"))
                       )
              )
              ,
              tabPanel("Other contingencies",value="topissue_element_contingencies",
                       plotOutput("topissue_contingencies"))
            )

    )),

    tabItem(tabName = "explorecontingencies",
            h2("Explore Contingencies"),
            hr(),

           fluidRow(
            column(7,
            fluidRow(
              column(4, 
                     fluidRow(
                       column(1),
                       column(11,selectInput("cont1","Contingency1",choices=sort(unique(data$contingency1)), selected=sort(unique(data$contingency1[nchar(data$contingency1)!=0]))[1]))),
                     fluidRow(
                       column(1),
                       column(11,selectInput("cont2","Contingency2",choices=sort(unique(data$contingency2)), selected=sort(unique(data[data$contingency1==sort(unique(data$contingency1))[1],contingency2]))[1])))),
              column(4, radioButtons("issue", "Issue Selection", choices=c("Loading Contingency <> Loading basecase"=1, "Loading Contingency > cutoff"=2)),
                conditionalPanel(
                  condition = "input.issue == 2",
                  textInput("cutoff", "CutOff", "120")
                )
              ),
              column(4, uiOutput("issueBox"))),
            fluidRow(
              column(12, DT::dataTableOutput("issuetable"))
            )),
              column(5, plotOutput("plotCont", click="plot_click"))
            ),

          br(),
          fluidRow(
            tabBox(
              title = tagList(shiny::icon("alert"), "Network Object Issues"), width = 12,
              tabPanel("Time Series",
                       "",
                       dygraphOutput("dygraph")
              ),
              tabPanel("Network Object Table",
                       "",
                       DT::dataTableOutput("elmtable"))
              
            )
         )
    )

  )
)

# Put them together into a dashboardPage
dashboardPage(
  dashboardHeader(title = "Elia Power Exploration", titleWidth = 300),
  sidebar,
  body
)
