#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(elia)
library(shinydashboard)
library(shinydashboardPlus)
library(ggplot2)
library(dygraphs)

data <- data
byvars <- c("network_object","contingency1","contingency2")
setkeyv(data, byvars)

# Define server logic required to draw a histogram
shinyServer(function(session, input, output) {



  ## REACTIVE > TOP ISSUES > top N issues ----
  topissues_topNelements <- reactive({
    ## deduplicate per issue; one issue is defined as combination of element, contingencies at the most critical timestamp
    var <-input$topissue_var
    tmp <- data[data[, .I[max_loading_perc==max(max_loading_perc)], by=eval(byvars)]$V1]
    # tmp <- data[, .SD[which.max(max_loading_perc)], by=c("network_object", "contingency1","contingency2")]
    tmp <- elia:::top.elia_power_analysis(tmp,var=var, type="n", n=10, verbose=F)
    tmp <- tmp[order(tmp[[var]], decreasing=TRUE)]
    return(tmp)
  })

  ## OUTPUT > TOP ISSUES > DT > top N table ----
  output$topissue_dt_elements <- DT::renderDataTable({
    tmp <- topissues_topNelements()
    tmp$time <- substr(tmp$time,1,5)
    var <-input$topissue_var
    keepvars <- c("network_object","contingency","date_str","time",var)
    DT::datatable(tmp[,keepvars, with=FALSE],options = list(ordering=FALSE, pageLength = 5),selection = list(mode = 'single', selected = c(1)))
  })

  ## REACTIVE > TOP ISSUES > selectedElement() ----
  selectedElement <- reactive({
    req(input$topissue_dt_elements_rows_selected)
    tmp <- topissues_topNelements()
    selrow <- input$topissue_dt_elements_rows_selected
    return(tmp[selrow,])
  })

  ## OUTPUT > TOP ISSUES > DYGRAPH > selected issue time serie ----
  output$topissue_timeseries_graph <- renderDygraph({
    req(input$topissue_dt_elements_rows_selected)

    fromelement <- selectedElement()


    fdata <- data[datakeys %in% fromelement$datakeys,]

    ts <- zoo::zoo(fdata[[input$topissue_var]], order.by = fdata[["datetime"]])
    maxdate <- fdata[["datetime"]][which.max(fdata[[input$topissue_var]])]
    dygraph(ts, main = paste(input$topissue_var, "of", fromelement[["network_object"]], "with", fromelement[["contingency"]], collapse=" ; ") ) %>%
      dyRangeSelector()%>%
      dyOptions(stackedGraph = TRUE)%>%
      dyEvent(maxdate, "max", labelLoc = "bottom",color="red") %>%
      dySeries("V1", label = input$topissue_var,strokeWidth = 2)
  })

  ## OUTPUT > TOP ISSUE > DT > correlated ts data ----
  output$topissue_correlations_dt <-  DT::renderDataTable({

    fromelement <- selectedElement()

    cors <- topcors()
    ## retrieve data

    fdata <- data[which(data$datakeys %in% names(cors)),]
    ## deduplicate: keep worse value per byvar
    tmp <- fdata[, .SD[which.max(max_loading_perc)], by=byvars]
    print(tmp)
    tmp$correlation <- cors[tmp[["datakeys"]]]
    var <-input$topissue_var
    keepvars <- c("network_object","contingency1","contingency2","correlation","date_str","time",var)
    DT::datatable(tmp[,keepvars, with=FALSE],options = list(ordering=FALSE, pageLength = 5),selection = 'single')
  })

  ## REACTIVE > TOP ISSUE > correlations ----
  topcors <- reactive({
    req(input$topissue_dt_elements_rows_selected)

    fromelement <- selectedElement()

    tmpw <- dataReshapeTs()
    tmpcor <- cor(tmpw[-1]) ## remove datetime from correlations computations

    selrow <- paste(fromelement[,byvars, with=FALSE],collapse=" ; ")
    irow <- which(rownames(tmpcor)==selrow)
    selcors <- tmpcor[irow,,drop=FALSE]
    selcors <- selcors[,-irow]
    selcors <- selcors[!is.na(selcors)]
    topcors <- selcors[order(abs(selcors),decreasing=TRUE)][1:5] ## may change the 5
    return(topcors)
  })

  ## REACTIVE > RESHAPE -> timeseries (by...) ----
  dataReshapeTs <- reactive({

    tmp <- data[,c("datetime",input$topissue_var),with=FALSE]
    tmp$varname <- apply(data[,byvars,with=FALSE], 1, paste, collapse=" ; ")
    tmpw <- reshape2::dcast(tmp,datetime~varname ,value.var=input$topissue_var, fun.aggregate = mean)
    return(tmpw)

  })


  ## OUTPUT > TOP ISSUE > PLOT > other contingencies ----
  output$topissue_contingencies <- renderPlot({
    fromelement <- selectedElement()
    fdata <- data[data$network_object==fromelement[["network_object"]],]

    ## retrieve top contingencies
    byvars <- c("network_object","contingency1","contingency2")


    setorderv(fdata, c(byvars,input$topissue_var),order=rep(-1,length(byvars)+1),na.last=TRUE)
    dedup <-fdata[!duplicated(fdata[,byvars,with=FALSE]),]
    setorderv(dedup, input$topissue_var, order=-1,na.last=TRUE)
    top6 <- dedup[1:6,]
    ## retrieve full time series of corresponding data
    sub1 <- data[data[["datakeys"]] %in% top6[["datakeys"]], ]
    sub1$contingency_full = paste(sub1$contingency1, sub1$contingency2, sep=" \n ")


    plot2a <-  ggplot(sub1, aes(x=loading_perc, y=max_loading_perc, color=contingency_full)) +
      facet_wrap(~contingency_full)+
      geom_point(size=2, alpha=0.6) +
      labs(title=paste("Correlation of N-1 loading and N loading \nfor object ",fromelement[["network_object"]]), x = "Loading N-1", y="Loading N") +
      guides(fill=FALSE, color=FALSE)+
      theme(
        strip.text.x = element_text(size = 6),
        plot.title = element_text(hjust = 0.5)) # to center title
    plot2a
  })

  ## OUTPUT > TOP ISSUE > DYGRAPH > correlated ts graph ----
  output$topissue_correlations_graph <- renderDygraph({
    req(input$topissue_dt_elements_rows_selected)

    fromelement <- selectedElement()
    tmpw <- dataReshapeTs()
    ## retrieve corresponding data
    selrow <- paste(fromelement[,byvars, with=FALSE],collapse=" ; ")
    tmpdatacors <- tmpw[,c(selrow,colnames(tmpw)[(colnames(tmpw)%in%names(topcors()))])]

    corts <- zoo::zoo( tmpdatacors, order.by=tmpw[["datetime"]])
    dygraph(corts, main = paste("time-series most correlated with", fromelement[["network_object"]]," having contingency", fromelement[["contingency"]])) %>%
      dyRangeSelector() %>%
      dyHighlight(highlightSeriesOpts = list(strokeWidth = 3),highlightSeriesBackgroundAlpha = 0.2)%>% dyLegend(show = "follow")
  })



    # Explore Contingencies Tab
  
    observe({
      conting2 <- sort(unique(data[data$contingency1==input$cont1,contingency2]))
      updateSelectInput(session, "Contingency2", choices=conting2, selected = conting2[1])
      
    })

    output$issueBox <- renderInfoBox({

      if(input$issue==1){
        N <- length(unique(data[data$contingency1 == input$cont1 & data$contingency2 == input$cont2 & data$max_loading_perc>data$loading_perc, network_object]))
      } else if(input$issue==2){
        N <- length(unique(data[data$contingency1 == input$cont1 & data$contingency2 == input$cont2 & data$max_loading_perc>= as.numeric(input$cutoff), network_object]))
      }
      if(N>0){
        infoBox(
          "issue", paste0(N, " errors"), icon = icon("alert"),
          color = "red"
        )
      }else{
        infoBox(
          "issue", paste0(N, " errors"), icon = icon("check"),
          color = "green"
        )
      }

    })


    fData_plotTop<- reactive({

      sub <- data[data$contingency1== input$cont1 & data$contingency2 == input$cont2]
      agg <- sub[, max(max_loading_perc), by=c("contingency1", "contingency2", "network_object")]
      top5 <- head(agg[order(agg$V1, decreasing = T)], n=5L)
      sub2 <- sub[sub$network_object %in% top5$network_object]
      sub2
      
    })
    
    output$plotCont <- renderPlot({

      sub2 <- setDT(fData_plotTop())
      cat("\n")
      print(sub2)

      plot2b <-  ggplot(sub2, aes(x=loading_perc, y=max_loading_perc, color=network_object, shape=network_object)) +
        geom_point(size=4, alpha=0.6) +
        labs(title=paste0("Correlation of N-1 loading and N loading \nfor", unique(sub2$contingency)), x = "Loading N-1", y="Loading N") +
        theme(plot.title = element_text(hjust = 0.5), legend.position = "left") # to center title

      plot2b
    })

    fData_cont<- reactive({

      req(input$cont1)
      sub <- data[data$contingency1== input$cont1 & data$contingency2 == input$cont2]
      sub <- sub[, maxLoad:=round(max(max_loading_perc, na.rm=T)), by=network_object]
      sub <- sub[, maxTime:=as.character(datetime[which.max(max_loading_perc)]), by =network_object]
      sub <- unique(sub[,.(contingency1, contingency2, network_object, maxLoad, maxTime)])
      elia:::top.elia_power_analysis(sub, var="maxLoad", type="n", n=50) 

    })

    output$issuetable <-  DT::renderDataTable({

      if(is.null(input$plot_click)){
        
        DT::datatable(fData_cont(),options = list(pageLength = 5),
                      selection = list(mode = 'single', selected = c(1)))
        
      }else if(!is.null(input$plot_click)){
        res <- nearPoints(data[data$contingency1== input$cont1 & data$contingency2 == input$cont2 & data$network_object %in% fData_plotTop()$network_object], input$plot_click, threshold = 100, maxpoints = 1)
        index <- fData_cont()[network_object%in%res$network_object, which=T]
        DT::datatable(fData_cont(),options = list(pageLength = 5),
                      selection = list(mode = 'single', selected = index))
        
      }

    })

    fData_selection <- reactive({
      
      req(fData_cont())
        sub <- fData_cont()[input$issuetable_rows_selected,]
        sub2 <- data[data$contingency1==input$cont1 & data$contingency2 == input$cont2 & data$network_object %in% sub$network_object,]
        sub2 <- sub2[,.(datetime, area, zone, branch, snom_mva, max_loading_perc, loading_perc, ratio, delta, relative_delta)]
        sub2 <- sub2[, datetime:=as.character(datetime)]
        num <-sapply(sub2, is.numeric)
        varnum <- names(num[num==1])
        sub2[,(varnum) := round(.SD,3), .SDcols=varnum]

    })

    output$elmtable = DT::renderDataTable({

      DT::datatable(fData_selection(), options = list(pageLength = 5))

    })

    output$dygraph <- renderDygraph({
      
      req(fData_selection())
      fdata=fData_selection()
      if (nrow(fdata)==0) return(NULL)
      setDT(fdata)
      t <- fdata[,.(datetime, max_loading_perc)]
      t <- as.data.frame(t[order(t$datetime)])
      txts <- xts::as.xts(t[,-1], order.by=as.POSIXct(t$datetime))
     

      dygraph(txts, main="Loading (N-1) over Time") %>%
        dyEvent(t[which.max(t$max_loading_perc), "datetime"], "Max", labelLoc = "bottom", color="red")%>%
        dyOptions(stackedGraph = TRUE) %>%
        dyRangeSelector()%>%
        dySeries("V1", label = "max_loading_perc",strokeWidth = 2)

    })

})
