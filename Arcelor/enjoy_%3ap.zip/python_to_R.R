
setwd('C:/Users/p/Desktop/mittal-hackaton/')

install.packages('rPython-win')
library(reticulate)
source_python("Search_engine_and_topic_prediction.py")


a = Search_engine_and_topic_prediction('risk valve')

